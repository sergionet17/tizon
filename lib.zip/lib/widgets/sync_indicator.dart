import 'package:flutter/material.dart';
import '../services/sync_status.dart';

class SyncIndicator extends StatelessWidget {
  const SyncIndicator({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<SyncState>(
      valueListenable: SyncStatus.state,
      builder: (context, state, _) {
        final msg = SyncStatus.message.value;

        String text;
        IconData icon;
        Color bg;

        switch (state) {
          case SyncState.offline:
            text = 'Sin internet';
            icon = Icons.cloud_off;
            bg = Colors.orange.shade700;
            break;

          case SyncState.idleOnline:
            text = 'Online • En espera';
            icon = Icons.cloud_done;
            bg = Colors.blueGrey.shade700;
            break;

          case SyncState.syncing:
            text = 'Sincronizando…';
            icon = Icons.sync;
            bg = Colors.green.shade700;
            break;

          case SyncState.error:
            text = 'Error sync';
            icon = Icons.error_outline;
            bg = Colors.red.shade700;
            break;
        }

        final extra = (msg != null && msg.isNotEmpty) ? ' • $msg' : '';

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(12),
            boxShadow: const [
              BoxShadow(
                blurRadius: 8,
                spreadRadius: 1,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                '$text$extra',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              if (state == SyncState.syncing) ...[
                const SizedBox(width: 8),
                const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }
}
